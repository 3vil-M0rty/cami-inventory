import React, { useState, useRef } from 'react';
import {
  Package, ShoppingCart, HardHat, Users, FileText,
  BarChart2, TrendingUp, Settings, Factory,
  Lock, LogOut, ChevronDown, Menu, X, Building2, Shovel, Sun, Moon
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useCompany } from '../../context/CompanyContext';
import { useAuth } from '../../context/AuthContext';
import NotifBell from '../../features/laquage/LaquageNotifBell';
import FourStatus from '../../features/laquage/FourStatus';
import ChangePasswordModal from '../../features/admin/ChangePasswordModal';
import { useBlsToReceive, canReceiveBls } from '../../features/orders/receptionQueue';

import './Header.css';

const NAV_ICONS = {
  inventory: <Package size={14} strokeWidth={2} />,
  orders: <ShoppingCart size={14} strokeWidth={2} />,
  projects: <HardHat size={14} strokeWidth={2} />,
  chantiers: <Shovel size={14} strokeWidth={2} />,
  clients: <Users size={14} strokeWidth={2} />,
  devis: <FileText size={14} strokeWidth={2} />,
  movements: <BarChart2 size={14} strokeWidth={2} />,
  analytics: <TrendingUp size={14} strokeWidth={2} />,
  admin: <Settings size={14} strokeWidth={2} />,
  ateliertables: <Factory size={14} strokeWidth={2} />,
};

const Header = ({ activePage, onNavigate }) => {
  const { t, currentLanguage, changeLanguage, languageLabels } = useLanguage();
  const { companies, selectedCompany, setSelectedCompany } = useCompany();
  const { user, logout, can } = useAuth();
  // Workshop accounts limited to a few articles: no company filter
  const restricted = (user?.restrictedItems || 0) > 0;
  // oven (four thermolaquage) and notification bell: shown according to the role (Administration › Rôles)
  const showFour = can('admin.view') || can('four.view') || can('four.edit');
  const showBell = can('admin.view') || can('notifications.view');

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showChangePwd, setShowChangePwd] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [theme, setTheme] = useState(() => (document.documentElement.dataset.theme === 'light' ? 'light' : 'dark'));
  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    if (next === 'light') document.documentElement.dataset.theme = 'light';
    else delete document.documentElement.dataset.theme;
    try { localStorage.setItem('app_theme', next); } catch (e) { }
  };

  const userMenuRef = useRef(null);
  // Delivery notes waiting for reception → count on the ACHATS link
  const { count: blsToReceive } = useBlsToReceive(canReceiveBls(user, can), user?.id || user?.username || '');
  const navBadge = (key) => (key === 'orders' && blsToReceive > 0
    ? <span className="hdr__nav-badge" title={t('blqBadgeTitle', { n: blsToReceive })}>{blsToReceive}</span> : null);

  const RECEIVING_ROLES = ['Magasinier', 'Laquage', 'Coordinateur-vitrage'];

  const navItems = [
    { key: 'inventory', label: t('navInventory'), perm: 'inventory.view' },
    { key: 'orders', label: t('navPurchases'), perm: 'orders.view' },
    { key: 'projects', label: t('navProjects'), perm: 'projects.view' },
    { key: 'chantiers', label: t('navChantiers') || 'Chantiers', perm: 'chantiers.view' },
    { key: 'clients', label: t('navClients'), perm: 'clients.view' },
    { key: 'devis', label: t('navDevis'), perm: 'devis.view' },
    { key: 'movements', label: t('navMovements'), perm: 'movements.view' },
    { key: 'analytics', label: t('navAnalytics'), perm: 'analytics.view' },
    { key: 'admin', label: t('navAdmin'), perm: 'admin.view' },
    { key: 'ateliertables', label: t('navAtelierTables'), perm: 'ateliertables.view' },
  ].filter(item =>
    item.key === 'orders'
      ? can(item.perm) || RECEIVING_ROLES.includes(user?.role)
      : can(item.perm)
  );

  const navigate = key => { onNavigate(key); setMobileOpen(false); };

  const handleLogout = () => { setShowUserMenu(false); logout(); };
  const handleChangePwd = () => { setShowChangePwd(true); setShowUserMenu(false); };

  const userDropdown = showUserMenu && (
    <>
      <div style={{ position: 'fixed', inset: 0, zIndex: 399 }} onClick={() => setShowUserMenu(false)} />
      <div className="hdr__dropdown" style={{ zIndex: 400 }}>
        <div className="hdr__dropdown-info">
          <strong>{user?.displayName}</strong>
          <span>@{user?.username}</span>
          <span className="hdr__dropdown-role">{user?.role}</span>
        </div>
        <button className="hdr__dropdown-item" onClick={handleChangePwd}>
          <Lock size={14} strokeWidth={2} />
          {t('changePassword')}
        </button>
        <button className="hdr__dropdown-item hdr__dropdown-logout" onClick={handleLogout}>
          <LogOut size={14} strokeWidth={2} />
          {t('logout')}
        </button>
      </div>
    </>
  );

  const langPicker = (
    <div className="hdr__lang">
      {Object.keys(languageLabels).map(code => (
        <button key={code}
          className={`hdr__lang-btn ${currentLanguage === code ? 'active' : ''}`}
          onClick={() => changeLanguage(code)}>
          {code.toUpperCase()}
        </button>
      ))}
    </div>
  );

  const themeLabel = theme === 'light' ? t('themeDark') : t('themeLight');
  const themeBtn = (
    <button type="button" className="hdr__theme-btn" onClick={toggleTheme} title={themeLabel} aria-label={themeLabel}>
      {theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
    </button>
  );

  const companyPills = (
    <>
      <button
        className={`hdr__company-pill ${!selectedCompany ? 'active' : ''}`}
        onClick={() => setSelectedCompany(null)}>
        <Building2 size={11} strokeWidth={2} />
        {t('allCompanies')}
      </button>
      {companies.map(c => (
        <button key={c.id}
          className={`hdr__company-pill ${selectedCompany === c.id ? 'active' : ''}`}
          style={{ '--cc': c.color }}
          onClick={() => setSelectedCompany(selectedCompany === c.id ? null : c.id)}>
          <span className="hdr__company-dot" style={{ background: c.color }} />
          {c.name}
        </button>
      ))}
    </>
  );

  return (
    <>
      <header className="hdr">

        <div className="hdr__top">

          {/* Brand */}
          <div className="hdr__brand">
            <div className="hdr__logo">
              <svg width="26" height="26" viewBox="0 0 32 32" fill="none">
                <rect x="2" y="2" width="28" height="28" rx="5" stroke="currentColor" strokeWidth="2" />
                <path d="M8 16L14 10L18 14L24 8" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="14" cy="10" r="1.8" fill="currentColor" />
                <circle cx="18" cy="14" r="1.8" fill="currentColor" />
                <circle cx="24" cy="8" r="1.8" fill="currentColor" />
              </svg>
            </div>
            <div className="hdr__brand-text">
              <span className="hdr__title">{t('appTitle')}</span>
              <span className="hdr__subtitle">{t('appSubtitle')}</span>
            </div>
          </div>

          {/* Desktop controls */}
          <div className="hdr__controls desktop-only">
            {!restricted && <div className="hdr__companies">{companyPills}</div>}
            {langPicker}
            {themeBtn}
            {showFour && <FourStatus />}
            {showBell && <NotifBell />}

            <div className="hdr__user" ref={userMenuRef}>

              <button className="hdr__user-btn" onClick={() => setShowUserMenu(v => !v)}>
                <span className="hdr__avatar">{user?.displayName?.charAt(0).toUpperCase()}</span>
                <span className="hdr__username">{user?.displayName}</span>
                <span className="hdr__role">{user?.role}</span>
                <ChevronDown size={12} strokeWidth={2} className="hdr__chevron" />
              </button>
              {userDropdown}
            </div>
          </div>

          {/* Mobile top-bar controls */}
          <div className="hdr__controls mobile-only" style={{ gap: 8 }}>
            {langPicker}
            {showFour && <FourStatus />}
            {showBell && <NotifBell />}
            <div className="hdr__user" ref={userMenuRef}>
              <button className="hdr__user-btn" onClick={() => setShowUserMenu(v => !v)}>
                <span className="hdr__avatar">{user?.displayName?.charAt(0).toUpperCase()}</span>
                <span className="hdr__username">{user?.displayName}</span>
                <span className="hdr__role">{user?.role}</span>
                <ChevronDown size={12} strokeWidth={2} className="hdr__chevron" />
              </button>
              {userDropdown}
            </div>
            <button
              className={`hdr__hamburger ${mobileOpen ? 'open' : ''}`}
              onClick={() => setMobileOpen(v => !v)}
              aria-label={t('acMenu')}
              style={{ display: 'flex' }}>
              <span /><span /><span />
            </button>
          </div>

        </div>

        {/* Desktop nav row */}
        <nav className="hdr__nav desktop-only">
          {navItems.map(item => (
            <button key={item.key}
              className={`hdr__nav-btn ${activePage === item.key ? 'active' : ''}`}
              onClick={() => navigate(item.key)}>
              <span className="hdr__nav-icon">{NAV_ICONS[item.key]}</span>
              {item.label}
              {navBadge(item.key)}
            </button>
          ))}
        </nav>

      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="hdr__mobile-overlay" onClick={() => setMobileOpen(false)}>
          <aside className="hdr__mobile-drawer" onClick={e => e.stopPropagation()}>

            <div className="hdr__mobile-top">
              <span className="hdr__title" style={{ fontSize: 16 }}>{t('appTitle')}</span>
              <button className="hdr__mobile-close" onClick={() => setMobileOpen(false)}>
                <X size={16} strokeWidth={2} />
              </button>
            </div>

            {!restricted && (
              <div style={{ padding: '14px 20px 14px', borderBottom: '1px solid var(--border)' }}>
                <div className="hdr__mobile-label" style={{ marginBottom: 8 }}>{t('company') || 'Société'}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>{companyPills}</div>
              </div>
            )}

            <nav className="hdr__mobile-nav">
              {navItems.map(item => (
                <button key={item.key}
                  className={`hdr__mobile-nav-btn ${activePage === item.key ? 'active' : ''}`}
                  onClick={() => navigate(item.key)}>
                  <span className="hdr__nav-icon">{NAV_ICONS[item.key]}</span>
                  {item.label}
                  {navBadge(item.key)}
                </button>
              ))}
            </nav>

            <div className="hdr__mobile-footer">
              {/* Language switcher — moved here from the crowded top bar */}
              <div className="hdr__mobile-section">
                <div className="hdr__mobile-label">{t('language')}</div>
                <div className="hdr__mobile-lang">
                  {Object.keys(languageLabels).map(code => (
                    <button key={code}
                      className={`hdr__lang-btn ${currentLanguage === code ? 'active' : ''}`}
                      onClick={() => changeLanguage(code)}>
                      {code.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
              <div className="hdr__mobile-section">
                <div className="hdr__mobile-label">{t('themeTitle')}</div>
                <button type="button" className="hdr__mobile-theme" onClick={toggleTheme}>
                  {theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
                  {themeLabel}
                </button>
              </div>
              <div className="hdr__mobile-section hdr__mobile-user">
                <span className="hdr__avatar hdr__avatar--lg">
                  {user?.displayName?.charAt(0).toUpperCase()}
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {user?.displayName}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)' }}>@{user?.username}</div>
                  <div style={{ marginTop: 3 }}>
                    <span className="hdr__role" style={{ fontSize: 10 }}>{user?.role}</span>
                  </div>
                </div>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, flexShrink: 0 }}>
                  <button className="hdr__mobile-action-btn"
                    onClick={() => { setShowChangePwd(true); setMobileOpen(false); }}>
                    <Lock size={15} strokeWidth={2} />
                  </button>
                  <button className="hdr__mobile-action-btn danger" onClick={handleLogout}>
                    <LogOut size={15} strokeWidth={2} />
                  </button>
                </div>
              </div>
            </div>

          </aside>
        </div>
      )}

      {showChangePwd && <ChangePasswordModal onClose={() => setShowChangePwd(false)} />}
    </>
  );
};

export default Header;