import React, { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import {
  Bell, Clock, X, CheckCircle2, AlertTriangle,
  Send, RotateCcw, PackageCheck, Trash2, ShoppingCart, Package
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { dialog } from '../../components/common/dialog';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
const POLL_MS = 20_000;
const LS_READ = 'notif_bell_read_ids';
const PRUNE_MS = 30 * 24 * 60 * 60 * 1000;

function getNotifId(ev) {
  if (ev._type === 'purchase') return `pr_${ev._id}`;
  if (ev._type === 'reception') return `rec_${ev.orderId}_${ev.lineId}_${new Date(ev.at).getTime()}`;
  return `laq_${ev.action}_${ev.projectId}_${new Date(ev.at).getTime()}`;
}

function loadReadIds() {
  try {
    const raw = JSON.parse(localStorage.getItem(LS_READ) || '{}');
    const cutoff = Date.now() - PRUNE_MS;
    return new Set(
      Object.entries(raw)
        .filter(([, ts]) => ts > cutoff)
        .map(([id]) => id)
    );
  } catch { return new Set(); }
}

function persistReadIds(newIds) {
  try {
    const raw = JSON.parse(localStorage.getItem(LS_READ) || '{}');
    const now = Date.now();
    const cutoff = now - PRUNE_MS;
    for (const id of newIds) { if (!raw[id]) raw[id] = now; }
    for (const id of Object.keys(raw)) { if (raw[id] < cutoff) delete raw[id]; }
    localStorage.setItem(LS_READ, JSON.stringify(raw));
  } catch { }
}

const LAQUAGE_META = {
  add_lot: { label: 'lnAddLot', color: '#818cf8', icon: <Package size={13} /> },
  send_to_laquage: { label: 'lnSent', color: '#fbbf24', icon: <Send size={13} /> },
  receive_all_laquage: { label: 'lnAllRecvLaq', color: '#60a5fa', icon: <PackageCheck size={13} /> },
  return_to_coord: { label: 'lnReturned', color: '#a78bfa', icon: <RotateCcw size={13} /> },
  receive_all_coord: { label: 'lnAllRecvCoord', color: '#4ade80', icon: <CheckCircle2 size={13} /> },
  incomplete_line: { label: 'lnIncomplete', color: '#f87171', icon: <AlertTriangle size={13} /> },
  receive_incomplete_line_laquage: {
    label: 'lnIncRecvLaq',
    color: '#60a5fa', icon: <PackageCheck size={13} />,
  },
  receive_incomplete_line_coord: {
    label: 'lnIncRecvCoord',
    color: '#4ade80', icon: <PackageCheck size={13} />,
  },
};
const RECEPTION_META = {
  label: 'lnOrderReception', color: '#4ade80', icon: <PackageCheck size={13} />,
};
function getLaquageMeta(action) {
  if (action.startsWith('receive_line_laquage:'))
    return { label: 'lnLineRecvLaq', color: '#60a5fa', icon: <PackageCheck size={13} /> };
  if (action.startsWith('receive_line_coord:'))
    return { label: 'lnLineRecvCoord', color: '#4ade80', icon: <CheckCircle2 size={13} /> };
  return LAQUAGE_META[action] || { label: action, color: '#9ca3af', icon: <Bell size={13} /> };
}

function fmtDT(d) {
  if (!d) return '—';
  const dt = new Date(d);
  return dt.toLocaleDateString('fr-FR') + ' ' +
    dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

/* ── Lot pill ─────────────────────────────────────────────────── */
function LotPill({ lotIndex }) {
  const { t } = useLanguage();
  if (lotIndex == null) return null;
  return (
    <span style={{
      fontSize: 9, fontWeight: 800, letterSpacing: '.04em',
      background: 'rgba(129,140,248,.12)', color: '#a5b4fc',
      border: '1px solid rgba(129,140,248,.3)',
      borderRadius: 4, padding: '1px 5px', flexShrink: 0,
      display: 'inline-flex', alignItems: 'center', gap: 3,
    }}>
      <Package size={9} /> {t('lnLot', { n: lotIndex + 1 })}
    </span>
  );
}

export default function NotifBell() {
  const { can } = useAuth();
  const { t } = useLanguage();
  const isAdmin = can('admin.view');

  const [events, setEvents] = useState([]);
  const [readIds, setReadIds] = useState(() => loadReadIds());
  const [open, setOpen] = useState(false);
  const [badge, setBadge] = useState(0);
  const [deleting, setDeleting] = useState(false);

  const fetchAll = useCallback(async () => {
    try {
      const requests = [
        axios.get(`${API_URL}/laquage/recent-actions?limit=30`).catch(() => ({ data: [] })),
        axios.get(`${API_URL}/orders/recent-receptions?limit=30`).catch(() => ({ data: [] })),
      ];
      if (isAdmin) {
        requests.push(
          axios.get(`${API_URL}/purchase-requests?status=ordered&limit=30`).catch(() => ({ data: [] }))
        );
      }
      const [laqRes, recRes, prRes] = await Promise.all(requests);

      const laqEvents = (laqRes.data || []).map(ev => ({ ...ev, _type: 'laquage' }));

      const recEvents = (recRes.data || []).map(r => ({
        _type: 'reception',
        action: 'order_reception',
        at: r.receivedAt,
        by: r.receivedBy || '—',
        projectName: r.itemName,
        projectRef: `+${r.quantityReceived} · BL ${r.blNumber}`,
        note: r.orderNumber ? `BC ${r.orderNumber}${r.companyName ? ' · ' + r.companyName : ''}` : null,
        orderId: r.orderId,
        lineId: r.lineId,
        category: r.category,
      }));

      const prEvents = isAdmin
        ? (prRes?.data || []).map(pr => ({
          _type: 'purchase',
          action: 'purchase_ordered',
          at: pr.orderedAt || pr.updatedAt,
          by: pr.orderedBy || 'ACHAT',
          projectName: pr.itemName,
          projectRef: t('lnQty', { n: pr.quantity }),
          note: pr.note || null,
          _id: pr.id || pr._id,
        }))
        : [];

      const all = [...laqEvents, ...recEvents, ...prEvents].sort((a, b) => new Date(b.at) - new Date(a.at));
      setEvents(all.slice(0, 40));
    } catch { }
  }, [isAdmin]);

  useEffect(() => {
    const currentRead = loadReadIds();
    const unread = events.filter(ev => !currentRead.has(getNotifId(ev))).length;
    setBadge(Math.min(unread, 9));
  }, [events, readIds]);

  useEffect(() => {
    fetchAll();
    const id = setInterval(fetchAll, POLL_MS);
    return () => clearInterval(id);
  }, [fetchAll]);

  const wrapRef = useRef(null);
  useEffect(() => {
    const h = e => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const markAllRead = useCallback(() => {
    const ids = events.map(getNotifId);
    persistReadIds(ids);
    setReadIds(loadReadIds());
    setBadge(0);
  }, [events]);

  const handleBellClick = () => {
    if (open) { setOpen(false); }
    else { markAllRead(); setOpen(true); }
  };

  const deleteOne = async (ev) => {
    if (deleting) return;
    setDeleting(true);
    try {
      if (ev._type === 'laquage') {
        await axios.delete(`${API_URL}/laquage/history-entry`, {
          data: { projectId: ev.projectId, action: ev.action, at: ev.at },
        });
        setEvents(prev => prev.filter(e =>
          !(e._type === 'laquage' &&
            String(e.projectId) === String(ev.projectId) &&
            e.action === ev.action &&
            new Date(e.at).getTime() === new Date(ev.at).getTime())
        ));
      } else if (ev._type === 'purchase') {
        await axios.delete(`${API_URL}/purchase-requests/${ev._id}`);
        setEvents(prev => prev.filter(e =>
          !(e._type === 'purchase' && String(e._id) === String(ev._id))
        ));
      }
    } catch { }
    finally { setDeleting(false); }
  };

  const clearAll = async () => {
    if (deleting) return;
    if (!(await dialog.confirm({ title: t('lnClearTitle'), message: t('lnClearConfirm'), danger: true, confirmLabel: t('lnClearAll') }))) return;
    setDeleting(true);
    try {
      await axios.delete(`${API_URL}/laquage/history-all`);
      setEvents(prev => prev.filter(e => e._type !== 'laquage'));
    } catch { }
    finally { setDeleting(false); }
  };

  const displayBadge = badge >= 9 ? '9+' : badge;
  const hasLaquage = events.some(e => e._type === 'laquage');
  const unreadCount = events.filter(ev => !readIds.has(getNotifId(ev))).length;

  /* ── Render a single notification row ────────────────────────── */
  const renderEvent = (ev, i) => {
    const isRead = readIds.has(getNotifId(ev));
    const rowStyle = {
      display: 'flex', gap: 12, padding: '11px 16px',
      borderBottom: '1px solid var(--border)', alignItems: 'flex-start',
      background: isRead ? 'transparent' : 'rgba(251,191,36,.05)',
      borderLeft: isRead ? '3px solid transparent' : '3px solid #fbbf24',
      opacity: isRead ? 0.62 : 1,
      transition: 'background .15s',
    };

    /* Purchase notification */
    if (ev._type === 'purchase') {
      return (
        <div key={`pr-${i}`} className="notif-row" style={rowStyle}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'rgba(251,191,36,.12)', border: '1px solid rgba(251,191,36,.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#fbbf24' }}>
            <ShoppingCart size={13} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#fcd34d', marginBottom: 2, display: 'flex', alignItems: 'center', gap: 5 }}>
              {t('lnPurchase')}
              {isRead && <span style={{ fontSize: 9, fontWeight: 600, color: 'var(--text-3)', background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 4, padding: '0 5px' }}>{t('lnSeen')}</span>}
            </div>
            <div style={{ fontSize: 12.5, color: 'var(--text)', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {ev.projectName}
              {ev.projectRef && <span style={{ color: 'var(--text-3)', fontWeight: 400 }}> · {ev.projectRef}</span>}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--text-3)', marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
              <Clock size={10} /> {fmtDT(ev.at)}
              {ev.by && ev.by !== '—' && <><span>·</span><span>{ev.by}</span></>}
            </div>
            {ev.note && (
              <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 5, padding: '3px 8px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6 }}>
                📝 {ev.note}
              </div>
            )}
          </div>
          {isAdmin && (
            <button className="notif-icon-btn notif-del-btn" onClick={() => deleteOne(ev)} disabled={deleting} title={t('delete')}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-4)', padding: 4, borderRadius: 6, flexShrink: 0, display: 'flex', alignItems: 'center', marginTop: 2 }}
              onMouseEnter={e => e.currentTarget.style.color = '#f87171'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-4)'}>
              <Trash2 size={12} />
            </button>
          )}
        </div>
      );
    }

    /* Laquage notification */
    const meta = ev._type === 'reception' ? RECEPTION_META : getLaquageMeta(ev.action);
    const laqType = ev.laqType || ev.recordType;
    const laqBadge = laqType === 'barres'
      ? { label: t('lnBars'), bg: 'rgba(251,146,60,.14)', color: '#fdba74', bd: 'rgba(251,146,60,.35)' }
      : laqType === 'accessoires'
        ? { label: t('lnAcc'), bg: 'rgba(248,113,113,.14)', color: '#fca5a5', bd: 'rgba(248,113,113,.35)' }
        : null;

    return (
      <div key={`lq-${i}`} className="notif-row" style={rowStyle}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: meta.color + '1f', border: '1px solid ' + meta.color + '40', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: meta.color }}>
          {meta.icon}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Action label row: type badge + action name + lot pill + read badge */}
          <div style={{ fontSize: 12, fontWeight: 700, color: meta.color, marginBottom: 2, display: 'flex', alignItems: 'center', gap: 5, flexWrap: 'wrap' }}>
            {laqBadge && (
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '.05em', background: laqBadge.bg, color: laqBadge.color, border: '1px solid ' + laqBadge.bd, borderRadius: 4, padding: '0 5px', flexShrink: 0 }}>
                {laqBadge.label}
              </span>
            )}
            {t(meta.label)}
            {/* ← NEW: show which lot this action belongs to */}
            <LotPill lotIndex={ev.lotIndex} />
            {isRead && (
              <span style={{ fontSize: 9, fontWeight: 600, color: 'var(--text-3)', background: 'var(--surface-3)', border: '1px solid var(--border-2)', borderRadius: 4, padding: '0 5px' }}>{t('lnSeen')}</span>
            )}
          </div>

          {/* Project name + ref */}
          {ev.projectName && (
            <div style={{ fontSize: 12.5, color: 'var(--text)', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {ev.projectName}
              {ev.projectRef && <span style={{ color: 'var(--text-3)', fontWeight: 400 }}> · {ev.projectRef}</span>}
            </div>
          )}

          {/* Time + author */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--text-3)', marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>
            <Clock size={10} /> {fmtDT(ev.at)}
            {ev.by && ev.by !== '—' && <><span>·</span><span>{ev.by}</span></>}
          </div>

          {/* Note (e.g. reception observation) */}
          {ev.note && (
            <div style={{ fontSize: 11, color: 'var(--text-2)', marginTop: 5, padding: '3px 8px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 6 }}>
              📝 {ev.note}
            </div>
          )}

          {/* Partial qty (e.g. received more/less than expected) */}
          {ev.partialQty != null && (
            <div style={{ fontSize: 11, color: '#93c5fd', marginTop: 5, padding: '3px 8px', background: 'rgba(96,165,250,.1)', border: '1px solid rgba(96,165,250,.25)', borderRadius: 6 }}>
              📦 {t('lnQtyReceived')} <strong>{ev.partialQty}</strong>
            </div>
          )}
        </div>

        {isAdmin && ev._type === 'laquage' && (
          <button className="notif-icon-btn notif-del-btn" onClick={() => deleteOne(ev)} disabled={deleting} title={t('delete')}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-4)', padding: 4, borderRadius: 6, flexShrink: 0, display: 'flex', alignItems: 'center', marginTop: 2 }}
            onMouseEnter={e => e.currentTarget.style.color = '#f87171'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--text-4)'}>
            <Trash2 size={12} />
          </button>
        )}
      </div>
    );
  };

  return (
    <div ref={wrapRef} style={{ position: 'relative', flexShrink: 0 }}>
      <style>{`
            @keyframes notifBellIn { from { opacity:0; transform:translateY(-8px) scale(.97); } to { opacity:1; transform:translateY(0) scale(1); } }
            .notif-bell-btn, .notif-icon-btn { padding: 0 !important; }
            .notif-icon-btn:hover { background: var(--surface-2) !important; color: var(--text) !important; }
            .notif-del-btn:hover { background: var(--danger-bg) !important; color: var(--danger) !important; }
            .notif-bell-btn:hover { background: var(--surface-3) !important; color: var(--text) !important; }
            .notif-row:hover { background: var(--surface-2) !important; }
            .notif-row:last-child { border-bottom: none !important; }
            .notif-bell-panel {
              position: absolute;
              top: calc(100% + 10px);
              right: 0;
              z-index: 9999;
              overflow: hidden;
            }
            @media (max-width: 768px) {
              .notif-bell-panel {
                position: fixed;
                top: 58px;
                right: 8px;
                left: 8px;
                width: auto !important;
                max-height: calc(100dvh - 74px);
                overflow-y: auto;
                border-radius: 12px;
              }
            }
          `}</style>

      {/* Bell button */}
      <button
        className="notif-bell-btn"
        onClick={handleBellClick}
        title={t('lnTitle')}
        style={{
          position: 'relative',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          width: 36, height: 36, padding: 0,
          background: open ? 'var(--surface-3)' : 'var(--surface-2)',
          border: '1px solid ' + (open ? 'var(--400)' : 'var(--border-2)'),
          borderRadius: '50%',
          cursor: 'pointer', color: open ? 'var(--text)' : 'var(--text-2)',
          transition: 'background .15s',
        }}>
        <Bell size={16} strokeWidth={2} />
        {badge > 0 && (
          <span style={{
            position: 'absolute', top: -5, right: -5,
            background: '#dc2626', color: '#fff',
            fontSize: 10, fontWeight: 800,
            minWidth: 18, height: 18, borderRadius: 999,
            padding: '0 4px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '2px solid var(--bg)',
            lineHeight: 1, whiteSpace: 'nowrap', boxSizing: 'border-box',
            pointerEvents: 'none',
          }}>
            {displayBadge}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div className="notif-bell-panel" style={{
          width: 'min(380px, 92vw)',
          background: 'var(--surface)', borderRadius: 14,
          boxShadow: 'var(--sh-xl), inset 0 1px 0 rgba(255,255,255,.04)',
          border: '1px solid var(--border)',
          animation: 'notifBellIn .18s ease',
        }}>

          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 12px 12px 16px', borderBottom: '1px solid var(--border)', background: 'var(--surface)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Bell size={15} style={{ color: 'var(--text-3)' }} />
              <span style={{ fontSize: 14, fontWeight: 800, color: 'var(--text)', letterSpacing: '-.01em' }}>{t('lnTitle')}</span>
              {unreadCount > 0 && (
                <span style={{ fontSize: 10, fontWeight: 700, background: 'var(--danger-bg)', color: '#fca5a5', border: '1px solid var(--danger-bd)', borderRadius: 999, padding: '0 7px' }}>
                  {t('lnUnread', { n: unreadCount })}
                </span>
              )}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              {isAdmin && hasLaquage && (
                <button onClick={clearAll} disabled={deleting} title={t('lnClearHistory')}
                  style={{ display: 'flex', alignItems: 'center', gap: 4, height: 28, padding: '0 10px', background: 'transparent', border: '1px solid var(--danger-bd)', borderRadius: 7, cursor: 'pointer', color: 'var(--danger)', fontSize: 11, fontWeight: 600, fontFamily: 'inherit', opacity: deleting ? .5 : 1 }}>
                  <Trash2 size={11} /> {t('lnClearAll')}
                </button>
              )}
              <button className="notif-icon-btn" onClick={() => setOpen(false)} style={{ background: 'none', border: '1px solid transparent', cursor: 'pointer', color: 'var(--text-3)', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, padding: 0, borderRadius: 7 }}>
                <X size={15} />
              </button>
            </div>
          </div>

          {/* Event list */}
          <div style={{ maxHeight: 420, overflowY: 'auto' }}>
            {events.length === 0 ? (
              <div style={{ padding: '36px 16px', textAlign: 'center', color: 'var(--text-3)', fontSize: 13, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
                <span style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-4)' }}>
                  <Bell size={18} />
                </span>
                {t('lnNone')}
              </div>
            ) : events.map((ev, i) => renderEvent(ev, i))}
          </div>

          {events.length > 0 && (
            <div style={{ padding: '9px 16px', borderTop: '1px solid var(--border)', background: 'var(--surface-2)', textAlign: 'center' }}>
              <span style={{ fontSize: 11, color: 'var(--text-3)' }}>
                {t('lnFooter', { n: events.length, r: events.length - unreadCount })}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}