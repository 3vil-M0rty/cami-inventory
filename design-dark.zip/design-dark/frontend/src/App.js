import { useState, useEffect } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { InventoryProvider } from './context/InventoryContext';
import { ProjectProvider } from './context/ProjectContext';
import { CompanyProvider } from './context/CompanyContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { useLanguage } from './context/LanguageContext';
import Header from './components/layout/Header';
import LoginPage from './features/admin/LoginPage';
import InventoryPage from './features/inventory/InventoryPage';
import ProjectsPage from './features/projects/ProjectsPage';
import AnalyticsPage from './features/analytics/AnalyticsPage';
import MovementsPage from './features/movements/MovementsPage';
import OrdersPage from './features/orders/OrdersPage';
import ClientsPage from './features/clients/ClientsPage';
import DevisPage from './features/devis/DevisPage';
import AdminPage from './features/admin/AdminPage';
import ChantierPage from './features/chantiers/ChantierPage';
import './App.css';
import AtelierTablesPage from './features/AtelierTables';
import { PAGE_PATHS, pageFromLocation, setUrl } from './routes';
import { DialogHost } from './components/common/dialog';

const PROJECTS_DEFAULT_ROLES = new Set(['LOGISTIQUE', 'Coordinateur', 'BARREMAN']);
const CHANTIER_DEFAULT_ROLES = new Set(['chefChantier', 'BARREMAN']);
// Rôles qui reçoivent des commandes par catégorie (accessoires / poudre / verre)
// et doivent donc accéder à la page Commandes même sans la permission orders.view
const ORDERS_RECEIVING_ROLES = new Set(['Magasinier', 'Laquage', 'Coordinateur-vitrage']);
const LS_PAGE = 'app_active_page';

function getDefaultPage(role) {
  if (CHANTIER_DEFAULT_ROLES.has(role)) return 'chantiers';
  if (PROJECTS_DEFAULT_ROLES.has(role)) return 'projects';
  return 'inventory';
}

function AppInner() {
  const { user, loading, can } = useAuth();
  const { t } = useLanguage();
  const [activePage, setActivePage] = useState('inventory');
  const [pageInitialized, setPageInitialized] = useState(false);

  // Page comes from the URL (/commandes, /projets…); "/" falls back to the last page / role default
  useEffect(() => {
    if (!loading && !pageInitialized) {
      if (user) {
        const page = pageFromLocation() || localStorage.getItem(LS_PAGE) || getDefaultPage(user.role);
        setActivePage(page);
        localStorage.setItem(LS_PAGE, page);
        if (!pageFromLocation()) setUrl(PAGE_PATHS[page] || '/', { replace: true });
      }
      setPageInitialized(true);
    }
  }, [loading, user, pageInitialized]);

  // Browser back / forward buttons
  useEffect(() => {
    const onPop = () => {
      const page = pageFromLocation();
      if (page) { setActivePage(page); localStorage.setItem(LS_PAGE, page); }
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const navigate = (page) => {
    localStorage.setItem(LS_PAGE, page);
    setActivePage(page);
    if (PAGE_PATHS[page]) {
      setUrl(PAGE_PATHS[page]);
      // let the open page react (e.g. Commandes clicked while a BC detail is open → back to the list)
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  };

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', background: '#f0f0f0', flexDirection: 'column', gap: 12
      }}>
        <div style={{ width: 36, height: 36, border: '3px solid #e5e7eb', borderTopColor: '#1a1a1a', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
        <p style={{ color: '#888', fontSize: '0.9rem' }}>{t('acCheckingSession')}</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLogin={(loggedInUser) => {
      // A link opened before logging in (e.g. /commandes/123) is kept; otherwise the role's default page
      const page = pageFromLocation() || getDefaultPage(loggedInUser?.role);
      localStorage.setItem(LS_PAGE, page);
      setActivePage(page);
      if (!pageFromLocation()) setUrl(PAGE_PATHS[page] || '/', { replace: true });
    }} />;
  }

  const pagePerms = {
    inventory: 'inventory.view', orders: 'orders.view', projects: 'projects.view',
    clients: 'clients.view', devis: 'devis.view', movements: 'movements.view',
    analytics: 'analytics.view', admin: 'admin.view', ateliertables: 'ateliertables.view',
    chantiers: 'chantiers.view',
  };

  // ── Accès à "orders" : permission classique OU rôle de réception par catégorie ──
  const canAccessOrders = can('orders.view') || ORDERS_RECEIVING_ROLES.has(user?.role);

  const currentAllowed =
    activePage === 'orders'
      ? canAccessOrders
      : (!pagePerms[activePage] || can(pagePerms[activePage]));

  return (
    <CompanyProvider>
      <InventoryProvider>
        <ProjectProvider>
          <div className="app">
            <Header activePage={activePage} onNavigate={navigate} />
            <main className="app__main">
              {!currentAllowed ? (
                <div style={{ textAlign: 'center', padding: 80 }}>
                  <div style={{ fontSize: '3rem', marginBottom: 12 }}>🔒</div>
                  <h2 style={{ color: '#374151' }}>{t('acAccessDenied')}</h2>
                  <p style={{ color: '#888' }}>{t('acNoPermission')}</p>
                </div>
              ) : (
                <>
                  {activePage === 'inventory'     && can('inventory.view')      && <InventoryPage />}
                  {activePage === 'orders'        && canAccessOrders            && <OrdersPage />}
                  {activePage === 'projects'      && can('projects.view')       && <ProjectsPage />}
                  {activePage === 'clients'       && can('clients.view')        && <ClientsPage />}
                  {activePage === 'devis'         && can('devis.view')          && <DevisPage />}
                  {activePage === 'analytics'     && can('analytics.view')      && <AnalyticsPage />}
                  {activePage === 'movements'     && can('movements.view')      && <MovementsPage />}
                  {activePage === 'admin'         && can('admin.view')          && <AdminPage />}
                  {activePage === 'ateliertables' && can('ateliertables.view')  && <AtelierTablesPage />}
                  {activePage === 'chantiers'     && can('chantiers.view')      && <ChantierPage />}
                </>
              )}
            </main>
          </div>
        </ProjectProvider>
      </InventoryProvider>
    </CompanyProvider>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppInner />
      </AuthProvider>
      {/* Custom alert / confirm / prompt dialogs and toasts (no browser pop-ups) */}
      <DialogHost />
    </LanguageProvider>
  );
}

export default App;