export { default } from './AtelierTablesPage';
