import React, { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import { Bell, Clock, X, CheckCircle2, AlertTriangle, Send, RotateCcw, PackageCheck, Trash2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const API_URL  = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
const POLL_MS  = 20_000; // poll every 20s
const LS_SEEN  = 'laq_bell_seen_at'; // ISO string — timestamp of last time user opened the bell

const ACTION_META = {
  send_to_laquage:     { label: 'Envoyé au laquage',               color: '#f59e0b', icon: <Send size={13}/> },
  receive_all_laquage: { label: 'Tout réceptionné (Laquage)',      color: '#3b82f6', icon: <PackageCheck size={13}/> },
  return_to_coord:     { label: 'Retourné au coordinateur',        color: '#8b5cf6', icon: <RotateCcw size={13}/> },
  receive_all_coord:   { label: 'Tout réceptionné (Coordinateur)', color: '#16a34a', icon: <CheckCircle2 size={13}/> },
  incomplete_line:     { label: 'Ligne signalée incomplète',       color: '#dc2626', icon: <AlertTriangle size={13}/> },
};

function getMeta(action) {
  return ACTION_META[action] || { label: action, color: '#9ca3af', icon: <Bell size={13}/> };
}

function fmtDT(d) {
  if (!d) return '—';
  const dt = new Date(d);
  return dt.toLocaleDateString('fr-FR') + ' ' + dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

export default function LaquageNotifBell() {
  const { can } = useAuth();
  const isAdmin = can('admin.view');

  const [events,   setEvents]   = useState([]);
  const [open,     setOpen]     = useState(false);
  const [badge,    setBadge]    = useState(0);   // the red number — never resets until user opens
  const [deleting, setDeleting] = useState(false);

  // seenAt = the timestamp the user last opened the bell
  // stored in a ref AND localStorage so it survives across polls without re-renders
  const seenAtRef = useRef(new Date(localStorage.getItem(LS_SEEN) || 0));

  // ── Fetch & recompute badge ──────────────────────────────────────────────
  const fetchEvents = useCallback(async () => {
    try {
      const res  = await axios.get(`${API_URL}/laquage/recent-actions?limit=20`);
      const data = res.data || [];
      setEvents(data);

      // Count how many events are newer than the last time user opened the bell
      const newCount = data.filter(ev => new Date(ev.at) > seenAtRef.current).length;
      setBadge(Math.min(newCount, 9)); // cap at 9 for display (shown as 9+)
    } catch { /* silent */ }
  }, []);

  // Initial fetch + interval
  useEffect(() => {
    fetchEvents();
    const id = setInterval(fetchEvents, POLL_MS);
    return () => clearInterval(id);
  }, [fetchEvents]);

  // Close on outside click
  const wrapRef = useRef(null);
  useEffect(() => {
    const h = e => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  // ── Open / close ─────────────────────────────────────────────────────────
  const handleBellClick = () => {
    if (open) {
      setOpen(false);
    } else {
      // Mark seen NOW — persist timestamp, reset badge
      const now = new Date();
      seenAtRef.current = now;
      localStorage.setItem(LS_SEEN, now.toISOString());
      setBadge(0);
      setOpen(true);
    }
  };

  // ── Admin: delete one ────────────────────────────────────────────────────
  const deleteOne = async (ev) => {
    if (deleting) return;
    setDeleting(true);
    try {
      await axios.delete(`${API_URL}/laquage/history-entry`, {
        data: { projectId: ev.projectId, action: ev.action, at: ev.at }
      });
      setEvents(prev => prev.filter(e =>
        !(String(e.projectId) === String(ev.projectId) &&
          e.action === ev.action &&
          new Date(e.at).getTime() === new Date(ev.at).getTime())
      ));
    } catch { /* silent */ }
    finally { setDeleting(false); }
  };

  // ── Admin: clear all ─────────────────────────────────────────────────────
  const clearAll = async () => {
    if (deleting) return;
    if (!window.confirm('Supprimer toutes les notifications laquage ?')) return;
    setDeleting(true);
    try {
      await axios.delete(`${API_URL}/laquage/history-all`);
      setEvents([]);
      setBadge(0);
    } catch { /* silent */ }
    finally { setDeleting(false); }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  const displayBadge = badge >= 9 ? '9+' : badge;

  return (
    <div ref={wrapRef} style={{ position: 'relative', flexShrink: 0 }}>

      {/* ── Bell button ── */}
      <button
        onClick={handleBellClick}
        title="Notifications laquage"
        style={{
          position: 'relative',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          width: 34, height: 34,
          background: open ? 'rgba(255,255,255,.18)' : 'rgba(255,255,255,.08)',
          border: '1px solid rgba(255,255,255,.18)',
          borderRadius: '50%',
          cursor: 'pointer', color: '#fff',
          transition: 'background .15s',
        }}
      >
        <Bell size={16} strokeWidth={2} />

        {/* Red badge — only shown when badge > 0 */}
        {badge > 0 && (
          <span style={{
            position: 'absolute', top: -5, right: -5,
            background: '#dc2626', color: '#fff',
            fontSize: 10, fontWeight: 800,
            minWidth: 18, height: 18,
            borderRadius: 999,
            padding: '0 4px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            border: '2px solid var(--900, #111)',
            lineHeight: 1, whiteSpace: 'nowrap',
            boxSizing: 'border-box',
            pointerEvents: 'none',
          }}>
            {displayBadge}
          </span>
        )}
      </button>

      {/* ── Dropdown ── */}
      {open && (
        <div style={{
          position: 'absolute', top: 'calc(100% + 10px)', right: 0,
          width: 'min(760px, 92vw)',
          background: '#fff', borderRadius: 14,
          boxShadow: '0 16px 60px rgba(0,0,0,.22)',
          border: '1px solid #e8e8e8',
          zIndex: 9999, overflow: 'hidden',
          animation: 'laqBellIn .18s ease',
        }}>
          <style>{`
            @keyframes laqBellIn {
              from { opacity: 0; transform: translateY(-8px) scale(.97); }
              to   { opacity: 1; transform: translateY(0)   scale(1);    }
            }
            .laq-notif-row:hover { background: #f9f9f9 !important; }
            .laq-notif-trash { opacity: 0; transition: opacity .15s; }
            .laq-notif-row:hover .laq-notif-trash { opacity: 1; }
          `}</style>

          {/* Header */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '12px 16px', borderBottom: '1px solid #f0f0f0', background: '#fafafa',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <Bell size={15} style={{ color: '#555' }} />
              <span style={{ fontSize: 13, fontWeight: 700, color: '#111' }}>Activité laquage</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              {isAdmin && events.length > 0 && (
                <button
                  onClick={clearAll}
                  disabled={deleting}
                  title="Tout supprimer (admin)"
                  style={{
                    display: 'flex', alignItems: 'center', gap: 4,
                    padding: '4px 9px',
                    background: '#fef2f2', border: '1px solid #fca5a5',
                    borderRadius: 6, cursor: 'pointer',
                    color: '#dc2626', fontSize: 11, fontWeight: 600,
                    fontFamily: 'inherit', transition: 'all .15s',
                    opacity: deleting ? .5 : 1,
                  }}
                >
                  <Trash2 size={11} /> Tout effacer
                </button>
              )}
              <button
                onClick={() => setOpen(false)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', display: 'flex', padding: 4 }}
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Event list */}
          <div style={{ maxHeight: 380, overflowY: 'auto' }}>
            {events.length === 0 ? (
              <div style={{ padding: '36px 16px', textAlign: 'center', color: '#bbb', fontSize: 13 }}>
                Aucune activité récente
              </div>
            ) : events.map((ev, i) => {
              const meta = getMeta(ev.action);
              return (
                <div
                  key={i}
                  className="laq-notif-row"
                  style={{
                    display: 'flex', gap: 12, padding: '11px 16px',
                    borderBottom: '1px solid #f5f5f5',
                    background: 'transparent',
                    transition: 'background .12s',
                    alignItems: 'flex-start',
                  }}
                >
                  {/* Icon */}
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%',
                    background: meta.color + '18',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    flexShrink: 0, color: meta.color,
                  }}>
                    {meta.icon}
                  </div>

                  {/* Content */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: meta.color, marginBottom: 2 }}>
                      {meta.label}
                    </div>
                    {ev.projectName && (
                      <div style={{ fontSize: 12, color: '#222', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {ev.projectName}
                        {ev.projectRef && <span style={{ color: '#888', fontWeight: 400 }}> · {ev.projectRef}</span>}
                      </div>
                    )}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#999', marginTop: 2 }}>
                      <Clock size={10} />
                      {fmtDT(ev.at)}
                      {ev.by && ev.by !== '—' && <><span>·</span><span>{ev.by}</span></>}
                    </div>
                    {ev.note && (
                      <div style={{ fontSize: 11, color: '#555', marginTop: 3, padding: '2px 7px', background: '#f5f5f5', borderRadius: 4 }}>
                        📝 {ev.note}
                      </div>
                    )}
                  </div>

                  {/* Admin trash */}
                  {isAdmin && (
                    <button
                      className="laq-notif-trash"
                      onClick={() => deleteOne(ev)}
                      disabled={deleting}
                      title="Supprimer"
                      style={{
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: '#ccc', padding: 2, flexShrink: 0,
                        display: 'flex', alignItems: 'center',
                        marginTop: 2,
                      }}
                      onMouseEnter={e => e.currentTarget.style.color = '#dc2626'}
                      onMouseLeave={e => e.currentTarget.style.color = '#ccc'}
                    >
                      <Trash2 size={13} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Footer */}
          {events.length > 0 && (
            <div style={{ padding: '9px 16px', borderTop: '1px solid #f0f0f0', background: '#fafafa', textAlign: 'center' }}>
              <span style={{ fontSize: 11, color: '#bbb' }}>
                {events.length} dernière{events.length > 1 ? 's' : ''} action{events.length > 1 ? 's' : ''}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}